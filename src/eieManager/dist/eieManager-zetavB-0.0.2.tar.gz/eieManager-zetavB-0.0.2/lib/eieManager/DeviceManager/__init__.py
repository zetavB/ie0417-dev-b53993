"""
device module entry point.
"""
