"""
sensor_commands module entry point.
"""

__author__ = 'Jordi Louzao von Breymann'
__email__ = 'jordi.louzao@ucr.ac.cr'
__version__ = '0.0.2'
